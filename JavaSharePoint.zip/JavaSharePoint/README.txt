SETUP: (Assumption: Running on Windows)

	This is running on Java Runtime Engine 8. You might need to upgrade to that, if you haven't already.

	Place the SPJava.jar file wherever you want - you can keep it in this folder. (Do note that at least one extra file will be made in the same directory as where the jar file is.)

	You can start the application by double clicking it (or however you normally start applications).

RUNNING SPJAVA.jar:

	Once you've started the application, the main window should load, and you can load any SharePoint 2010 site with Web Service extensions, assuming you have the proper credentials and that the application can handle the credentials. 

	To load a site, simply just type/paste the url into the box at the top of the frame, and hit enter to execute. Every URL you enter will be stored for later use, and can be deleted if wanted only by modifying the "SPJavaPrefs.txt" file (A GUI option for this can be added later).
The url should end at the site name, otherwise the site will fail to load. 

	examples:
	To load InternTestSite:
		https://sharepointfoundation.sites.emc.com/EMCITSharePoint/InternTestSite
	To load the main site:
		https://sharepointfoundation.sites.emc.com

	While loading the site, you may be asked for credentials. In that case, enter the domain, username, and password for the respective SharePoint site. If you don't use a domain, leave that field blank. The domain and username you pick will be stored for the next time, (it's not site specific [yet] so if you use multiple usernames/domains for different sites, you will need to keep reentering them.
If you cannot log in, press the escape window button to stop the log in process. 

	Once the site is loaded, all of the lists/libraries for the site will populate the left panel of the main window. Click on the list will cause the application to load all of the respective items form that list into the right panel.
If a library is selected, the upload button will be enabled, and you can upload files directly to that library by pressing the upload button.  You can also select items from the right panel, and download them. When you press the download button, a directory chooser will appear so you can specify where to store the files.

	If things seem buggy or over-encumbered, you can delete the SPJavaPrefs.text file, and you will be starting anew.
